import json
import boto3
import datetime
import logging

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize the SQS client
sqs_client = boto3.client('sqs')

# URL for AWS SQS in RG-1 (US East)
# Please replace your SQS URL 
queue_url = 'https://sqs.us-east-1.amazonaws.com/<account_id>/RG-1-Telemetry-Queue-US-East'

def lambda_handler(event, context):
    """
    AWS Lambda function to process telemetry data,
    add a timestamp, and forward the data to the SQS queue in RG-1.
    
    Parameters:
    event (dict): The event data received from the trigger.
    context (object): The context in which the function is called.

    Returns:
    dict: Status code and message.
    """
    logger.info(f"Received event: {json.dumps(event)}")
    
    try:
        # Check if the event is from API Gateway
        if 'body' in event:
            message_body = json.loads(event['body'])
        else:
            raise ValueError("Event does not contain 'body' key")

        # Add the Lambda function timestamp
        lambda_timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
        if 'timestamps' in message_body:
            message_body['timestamps']['RG_1_API_Gateway_timestamp'] = lambda_timestamp
        else:
            message_body['timestamps'] = {'RG_1_API_Gateway_timestamp': lambda_timestamp}

        try:
            # Send the updated message to the SQS queue in RG-1
            response = sqs_client.send_message(
                QueueUrl=queue_url,
                MessageBody=json.dumps(message_body)
            )
            logger.info(f"Message sent to RG-1 SQS successfully: {response}")
        except boto3.exceptions.Boto3Error as e:
            logger.error(f"Boto3Error: {str(e)} - Skipping this record")

        return {
            'statusCode': 200,
            'body': json.dumps('Messages processed successfully!')
        }

    except json.JSONDecodeError as e:
        error_message = f"JSONDecodeError: {str(e)}"
        logger.error(error_message)
        return {
            'statusCode': 400,
            'body': json.dumps({'error': error_message})
        }

    except ValueError as e:
        error_message = f"ValueError: {str(e)}"
        logger.error(error_message)
        return {
            'statusCode': 400,
            'body': json.dumps({'error': error_message})
        }

    except Exception as e:
        error_message = f"Exception: {str(e)}"
        logger.error(error_message)
        return {
            'statusCode': 500,
            'body': json.dumps({'error': error_message})
        }

