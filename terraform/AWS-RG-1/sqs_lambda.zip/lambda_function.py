import json
import boto3
import datetime
import logging
import urllib3

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize the SQS client
sqs_client = boto3.client('sqs')

# URL for API Gateway in RG-GOV-IMS
# Please configure the URL for api_gateway in RG-GOV-IM
api_gateway_url = 'https://<id>.execute-api.us-east-1.amazonaws.com/prod/telemetry'

def lambda_handler(event, context):
    """
    AWS Lambda function to forward telemetry data from SQS in RG-1
    to the API Gateway in RG-GOV-IMS.
    
    Parameters:
    event (dict): The event data received from SQS.
    context (object): The context in which the function is called.

    Returns:
    dict: Status code and message.
    """
    logger.info(f"Received event: {json.dumps(event)}")
    
    try:
        # Initialize urllib3 PoolManager
        http = urllib3.PoolManager()

        # Process each record in the event
        for record in event['Records']:
            message_body = json.loads(record['body'])

            # Add the Lambda function timestamp
            forwarder_timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
            if 'timestamps' in message_body:
                message_body['timestamps']['RG_1_SQS_Forwarder_timestamp'] = forwarder_timestamp
            else:
                message_body['timestamps'] = {'RG_1_SQS_Forwarder_timestamp': forwarder_timestamp}

            logger.info(f"Modified message body: {json.dumps(message_body)}")

            # Send the updated message to the API Gateway in RG-GOV-IMS
            encoded_data = json.dumps(message_body).encode('utf-8')
            response = http.request(
                'POST',
                api_gateway_url,
                body=encoded_data,
                headers={'Content-Type': 'application/json'}
            )
            
            if response.status != 200:
                raise ValueError(f"Request to API Gateway failed: {response.status} {response.data}")

            logger.info(f"Message sent to API Gateway successfully: {response.data.decode('utf-8')}")

        return {
            'statusCode': 200,
            'body': json.dumps('Messages processed successfully!')
        }

    except json.JSONDecodeError as e:
        error_message = f"JSONDecodeError: {str(e)}"
        logger.error(error_message)
        return create_response(400, error_message)

    except ValueError as e:
        error_message = f"ValueError: {str(e)}"
        logger.error(error_message)
        return create_response(500, error_message)

    except Exception as e:
        error_message = f"Exception: {str(e)}"
        logger.error(error_message)
        return create_response(500, error_message)

def create_response(status_code, message):
    """
    Create a response object.
    
    Parameters:
    status_code (int): The status code of the response.
    message (str): The message to include in the response.
    
    Returns:
    dict: The response object.
    """
    return {
        'statusCode': status_code,
        'body': json.dumps({'error': message})
    }

