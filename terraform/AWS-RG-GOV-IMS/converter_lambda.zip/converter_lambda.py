import json
import boto3
import datetime
import logging

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize the SNS client
sns_client = boto3.client('sns')

# SNS topic ARN for "Archiver"
archiver_topic_arn = 'arn:aws:sns:us-east-1:<account_id>:Archiver'

def lambda_handler(event, context):
    """
    AWS Lambda function to process telemetry data,
    adjust the format, add a timestamp, and forward the data to the SNS Archiver topic.

    Parameters:
    event (dict): The event data received from the trigger.
    context (object): The context in which the function is called.

    Returns:
    dict: Status code and message.
    """
    logger.info(f"Received event: {json.dumps(event)}")

    try:
        # Process each record in the event
        for record in event['Records']:
            message_body = json.loads(record['Sns']['Message'])
            logger.info(f"Original message body: {json.dumps(message_body)}")

            # Adjust the format of the JSON (for now, let's assume it involves reorganizing some fields)
            organized_message = convert_to_organized_log(message_body)

            # Add the Lambda function timestamp
            converter_timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
            if 'timestamps' in organized_message:
                organized_message['timestamps']['RG_GOV_IMS_Converter_timestamp'] = converter_timestamp
            else:
                organized_message['timestamps'] = {'RG_GOV_IMS_Converter_timestamp': converter_timestamp}

            logger.info(f"Modified message body: {json.dumps(organized_message)}")

            # Send the updated message to the SNS Archiver topic
            response = sns_client.publish(
                TopicArn=archiver_topic_arn,
                Message=json.dumps(organized_message)
            )
            logger.info(f"Message sent to SNS Archiver topic successfully: {response}")

        return {
            'statusCode': 200,
            'body': json.dumps('Messages processed successfully!')
        }

    except json.JSONDecodeError as e:
        error_message = f"JSONDecodeError: {str(e)}"
        logger.error(error_message)
        return create_response(400, error_message)

    except boto3.exceptions.Boto3Error as e:
        error_message = f"Boto3Error: {str(e)}"
        logger.error(error_message)
        return create_response(500, error_message)

    except Exception as e:
        error_message = f"Exception: {str(e)}"
        logger.error(error_message)
        return create_response(500, error_message)

def convert_to_organized_log(message):
    """
    Convert the incoming message to a more organized log format.

    Parameters:
    message (dict): The original message.

    Returns:
    dict: The organized message.
    """
    # Implement the logic to adjust the format of the JSON
    # For this example, let's assume we're just sorting the keys
    organized_message = {k: message[k] for k in sorted(message.keys())}
    return organized_message

def create_response(status_code, message):
    """
    Create a response object.

    Parameters:
    status_code (int): The status code of the response.
    message (str): The message to include in the response.

    Returns:
    dict: The response object.
    """
    return {
        'statusCode': status_code,
        'body': json.dumps({'error': message})
    }
