import json
import boto3
import datetime
import logging

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Initialize the S3 client
s3_client = boto3.client('s3')

# S3 bucket names , please make sure to update this according to your settings
mutable_bucket_name = 'rg-gov-ims-telemetry-archive-mutable-us-east'
immutable_bucket_name = 'rg-gov-ims-telemetry-archive-immutable-us-east'

def lambda_handler(event, context):
    """
    AWS Lambda function to process telemetry data,
    add a timestamp, and store the data in S3 with or without object lock based on data_type.

    Parameters:
    event (dict): The event data received from the trigger.
    context (object): The context in which the function is called.

    Returns:
    dict: Status code and message.
    """
    logger.info(f"Received event: {json.dumps(event)}")

    try:
        # Process each record in the event
        for record in event['Records']:
            message_body = json.loads(record['Sns']['Message'])
            logger.info(f"Original message body: {json.dumps(message_body)}")

            # Add the Lambda function timestamp
            archiver_timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
            if 'timestamps' in message_body:
                message_body['timestamps']['RG_GOV_IMS_Archiver_timestamp'] = archiver_timestamp
            else:
                message_body['timestamps'] = {'RG_GOV_IMS_Archiver_timestamp': archiver_timestamp}

            logger.info(f"Modified message body: {json.dumps(message_body)}")

            # Determine the CSP and prefix the object key
            csp = message_body.get('CSP', '').lower()  # Assuming CSP is provided in the message
            prefix = f"{csp}-" if csp in ['aws', 'ibm'] else ""

            # Determine the bucket and storage type based on data_type
            data_type = message_body.get('data_type')
            log_id = message_body.get('log_id')
            object_key = f"{prefix}{log_id}.json"

            if data_type == 'metrics':
                # Store in mutable S3 bucket
                response = s3_client.put_object(
                    Bucket=mutable_bucket_name,
                    Key=object_key,
                    Body=json.dumps(message_body),
                    ContentType='application/json'
                )
                logger.info(f"Message stored in mutable S3 bucket: {response}")
            elif data_type in ['logs', 'traces']:
                # Store in immutable S3 bucket with object lock
                response = s3_client.put_object(
                    Bucket=immutable_bucket_name,
                    Key=object_key,
                    Body=json.dumps(message_body),
                    ContentType='application/json',
                    ObjectLockMode='GOVERNANCE',
                    ObjectLockRetainUntilDate=(datetime.datetime.now(datetime.timezone.utc) +
                                               datetime.timedelta(days=365)).isoformat()
                )
                logger.info(f"Message stored in immutable S3 bucket with object lock: {response}")
            else:
                logger.warning(f"Unknown data_type: {data_type}. Skipping record.")

        return {
            'statusCode': 200,
            'body': json.dumps('Messages processed and stored successfully!')
        }

    except json.JSONDecodeError as e:
        error_message = f"JSONDecodeError: {str(e)}"
        logger.error(error_message)
        return create_response(400, error_message)

    except boto3.exceptions.Boto3Error as e:
        error_message = f"Boto3Error: {str(e)}"
        logger.error(error_message)
        return create_response(500, error_message)

    except Exception as e:
        error_message = f"Exception: {str(e)}"
        logger.error(error_message)
        return create_response(500, error_message)

def create_response(status_code, message):
    """
    Create a response object.

    Parameters:
    status_code (int): The status code of the response.
    message (str): The message to include in the response.

    Returns:
    dict: The response object.
    """
    return {
        'statusCode': status_code,
        'body': json.dumps({'error': message})
    }
