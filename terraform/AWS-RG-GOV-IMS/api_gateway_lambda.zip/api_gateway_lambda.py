import json
import boto3
import datetime
import logging

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Inƒitialize the SNS client
sns_client = boto3.client('sns')

# ARN for the SNS Converter topic
sns_topic_arn = 'arn:aws:sns:us-east-1:<account_id>:Converter'

def lambda_handler(event, context):
    """
    AWS Lambda function to process telemetry data,
    add a timestamp, and forward the data to the SNS Converter topic.

    Parameters:
    event (dict): The event data received from the API Gateway.
    context (object): The context in which the function is called.

    Returns:
    dict: Status code and message.
    """
    logger.info(f"Received event: {json.dumps(event)}")

    try:
        # Check if the event is from API Gateway
        if 'body' in event:
            message_body = json.loads(event['body'])
        else:
            raise ValueError("Event does not contain 'body' key")

        # Add the Lambda function timestamp
        data_ingestor_timestamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
        if 'timestamps' in message_body:
            message_body['timestamps']['RG_GOV_IMS_API_Gateway_timestamp'] = data_ingestor_timestamp
        else:
            message_body['timestamps'] = {'RG_GOV_IMS_API_Gateway_timestamp': data_ingestor_timestamp}

        logger.info(f"Modified message body: {json.dumps(message_body)}")

        # Send the updated message to the SNS Converter topic
        response = sns_client.publish(
            TopicArn=sns_topic_arn,
            Message=json.dumps(message_body)
        )
        logger.info(f"Message sent to SNS Converter topic successfully: {response}")

        return {
            'statusCode': 200,
            'body': json.dumps('Messages processed successfully!')
        }

    except json.JSONDecodeError as e:
        log_error(f"JSONDecodeError: {str(e)}")
        return create_response(400, f"JSONDecodeError: {str(e)}")

    except boto3.exceptions.Boto3Error as e:
        log_error(f"Boto3Error: {str(e)}")
        return create_response(500, f"Boto3Error: {str(e)}")

    except ValueError as e:
        log_error(f"ValueError: {str(e)}")
        return create_response(400, f"ValueError: {str(e)}")

    except Exception as e:
        log_error(f"Exception: {str(e)}")
        return create_response(500, f"Exception: {str(e)}")

def log_error(error_message):
    """
    Log an error message.

    Parameters:
    error_message (str): The error message to log.
    """
    logger.error(error_message)

def create_response(status_code, message):
    """
    Create a response object.

    Parameters:
    status_code (int): The status code of the response.
    message (str): The message to include in the response.

    Returns:
    dict: The response object.
    """
    return {
        'statusCode': status_code,
        'body': json.dumps({'error': message})
    }
